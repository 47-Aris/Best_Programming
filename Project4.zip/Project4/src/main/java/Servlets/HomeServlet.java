package Servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Servlet implementation class HomeServlet
 */
@WebServlet("/home")
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	private static final Logger Logger = LogManager.getLogger(HomeServlet.class);
	
    public HomeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().print("<h1>Hello My name is BIZIMUNGU Aristide and My Id is 25254</h1>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String entereId = request.getParameter("id");
		if(!entereId.matches("\\d+")) {
			response.getWriter().print("<h1>Id must be number</h1>");
			return;
		}
		Integer id = Integer.parseInt(entereId);
		try {
			String db_url= "jdbc:postgresql://localhost:5432/best_pro_db";
			String username = "postgres";
			String password = "Kaizen11";
			Class.forName("org.postgresql.Driver");
			Logger.info("Loaded postgresql driver");
			Connection con = DriverManager.getConnection(db_url,username,password);
			PreparedStatement pst = con.prepareStatement("select * from student where id = ?");
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				String name = rs.getString("names");
	
				response.getWriter().print("<h1>Your Name is "+name+" and id is "+id+" </h1>");
				
			}
			con.close();
			return;
			
		} catch (SQLException e) {
			Logger.error("SQL exceptions caought: connection to db failed");
			
		} catch (ClassNotFoundException e) {
			Logger.error("Some class was not found"+e);
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.getWriter().print("<h2>id does not exist</h2>");
	}
	

}
